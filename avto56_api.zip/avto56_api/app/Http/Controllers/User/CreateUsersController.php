<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\StoreRequest;
use Illuminate\Http\Request;
use  App\Models\User;  
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class CreateUsersController extends Controller
{
    public function create(StoreRequest $request) {
        $user = auth()->user();

        if($user['role'] == 'admin') {
            $data = $request->validated();
            $data['password'] = Hash::make($data['password']);
            
            User::firstOrCreate([
                'username' => $data['username'],
            ], $data);

            return response([
                "message" => "create user",
            ], 200);
        }
        
        return response([
            'message' => 'Invalid role'
        ],404);
    }

    public function update(StoreRequest $request) {

        // $data = $request->validated();
        // $data['password'] = Hash::make($data['password']);
        
        // User::firstOrCreate([
        //     'username' => $data['username'],
        // ], $data);

        return response([
            "message" => "update user",
        ], 200);
    }
}
