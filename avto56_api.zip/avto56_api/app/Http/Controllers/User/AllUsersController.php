<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class AllUsersController extends Controller
{
    public function index() {
        $table = DB::table("users")
            ->select('id', 'name', 'username', 'role', 'incpector','created_at', 'updated_at')
            ->where('role','cabet')
            ->get();

        return response($table, 200);
    }
}
